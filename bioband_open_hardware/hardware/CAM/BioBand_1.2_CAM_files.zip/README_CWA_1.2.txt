CWA Version 1.2
Manufacturing notes

The Farnell part numbers on the BOM are for reference only. It is not a requirement
that all parts are purchased from Farnell.

There are a couple of changes to the BOM from version 1.1:
- D1, the LED, is now an Avago (HP) HSMF-C114. This will need to be bought.
- U5 is actually a 0R resistor the same as the others on the board. It's a dummy
to keep the interface between Altium Designer and XJTAG happy.

The PCB thickness is to be 1mm.

The lands left holding each board into the panel should be on the short
edges of the board - the long edges are used for location in a later
manufacturing process.

The layer order is:

biobank_CWA.gtl (top)
biobank_CWA.gp1 (ground plane)
biobank_CWA.g1  (inner routing)
biobank_CWA.gbl (bottom)

Position J2 should be left unfitted.

Chris Jones
Martin-Jones Technology Ltd
chris@martin-jones.com
01223 655611
2 September 2010