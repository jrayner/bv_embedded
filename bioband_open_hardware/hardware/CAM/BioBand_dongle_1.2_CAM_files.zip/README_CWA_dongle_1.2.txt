CWA Dongle Version 1.2
Manufacturing notes

The Farnell part numbers on the BOM are for reference only. It is not a requirement
that all parts are purchased from Farnell.

The PCB thickness is to be 1.6mm.

The layers are:

biobank_CWA_dongle.GTL Top Layer
biobank_CWA_dongle.GBL Bottom Layer
biobank_CWA_dongle.GTO Top Overlay
biobank_CWA_dongle.GTS Top Solder
biobank_CWA_dongle.GBS Bottom Solder
biobank_CWA_dongle.GD1 Drill Drawing
biobank_CWA_dongle.GTP Top Paste

Chris Jones
Martin-Jones Technology Ltd
chris@martin-jones.com
01223 655611
11 October 2010